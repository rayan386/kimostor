<?php if (function_exists('cartsy_lite_social_profile')) { ?>
<div class="cartsylite-copyright-social-area">
    <?php echo cartsy_lite_social_profile(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
</div>
<?php } ?>